INSERT INTO RESERVAS VALUES (
idCliente = X, idEspacio = Y, duracion = Z, fechaInicio = B, fechaReserva = E, cancelado = H, precio = P);
--LOS VALORES X,Y,Z sucesivamente son los que en el proyecot java son reemplazados por los nuevos valores de cada atributo.